import express from 'express';
import { Team } from '../db';

const router = express.Router();

// Get all users


export default router;